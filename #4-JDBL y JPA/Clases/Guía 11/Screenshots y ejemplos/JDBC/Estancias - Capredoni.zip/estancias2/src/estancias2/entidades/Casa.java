package estancias2.entidades;

import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author Pablo
 */
public class Casa {

    private Integer id_casa;  // PK
    private String calle;
    private Integer numero;
    private String codigo_postal;
    private String ciudad;
    private String pais;
    private LocalDate fecha_desde;  // en SQL son "date"
    private LocalDate fecha_hasta;
    private Integer tiempo_minimo;
    private Integer tiempo_maximo;
    private Double precio_habitacion;  // en SQL es "NUMERIC"
    private String tipo_vivienda;

    public Casa(Integer id_casa, String calle, Integer numero, String codigo_postal, String ciudad, String pais, LocalDate fecha_desde, LocalDate fecha_hasta, Integer tiempo_minimo, Integer tiempo_maximo, Double precio_habitacion, String tipo_vivienda) {
        this.id_casa = id_casa;
        this.calle = calle;
        this.numero = numero;
        this.codigo_postal = codigo_postal;
        this.ciudad = ciudad;
        this.pais = pais;
        this.fecha_desde = fecha_desde;
        this.fecha_hasta = fecha_hasta;
        this.tiempo_minimo = tiempo_minimo;
        this.tiempo_maximo = tiempo_maximo;
        this.precio_habitacion = precio_habitacion;
        this.tipo_vivienda = tipo_vivienda;
    }

    public Casa() {
    }

    public Integer getId_casa() {
        return id_casa;
    }

    public void setId_casa(Integer id_casa) {
        this.id_casa = id_casa;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public LocalDate getFecha_desde() {
        return fecha_desde;
    }

    public void setFecha_desde(String fecha_desde) {
        LocalDate localDate = Date.valueOf(fecha_desde).toLocalDate();
        this.fecha_desde = localDate;
    }

    public LocalDate getFecha_hasta() {
        return fecha_hasta;
    }

    public void setFecha_hasta(String fecha_hasta) {
        LocalDate localDate = Date.valueOf(fecha_hasta).toLocalDate();
        this.fecha_hasta = localDate;
    }

    public Integer getTiempo_minimo() {
        return tiempo_minimo;
    }

    public void setTiempo_minimo(Integer tiempo_minimo) {
        this.tiempo_minimo = tiempo_minimo;
    }

    public Integer getTiempo_maximo() {
        return tiempo_maximo;
    }

    public void setTiempo_maximo(Integer tiempo_maximo) {
        this.tiempo_maximo = tiempo_maximo;
    }

    public Double getPrecio_habitacion() {
        return precio_habitacion;
    }

    public void setPrecio_habitacion(Double precio_habitacion) {
        this.precio_habitacion = precio_habitacion;
    }

    public String getTipo_vivienda() {
        return tipo_vivienda;
    }

    public void setTipo_vivienda(String tipo_vivienda) {
        this.tipo_vivienda = tipo_vivienda;
    }

    public String getCodigo_postal() {
        return codigo_postal;
    }

    public void setCodigo_postal(String codigo_postal) {
        this.codigo_postal = codigo_postal;
    }

    public void imprimirCasa() {
        System.out.println("ID: "+id_casa+
                "\n   Calle: "+calle+
                "\n   Numero: "+numero+
                "\n   Codigo postal: "+codigo_postal+
                "\n   Ciudad: "+ciudad+
                "\n   Pais: "+pais+
                "\n   Fecha Desde: "+fecha_desde+
                "\n   Fecha Hasta: "+fecha_hasta+
                "\n   Tiempo maximo: "+tiempo_maximo+
                "\n   Tiempo minimo: "+tiempo_minimo+
                "\n   Precio por día: "+precio_habitacion+
                "\n   Tipo de vivienda: "+tipo_vivienda);
    }
}
