package estancias2.persistencia;

import estancias2.entidades.Comentario;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class ComentarioDAO extends DAO{

    public ArrayList <Comentario> listarComentarios() throws Exception {
        try {
            String sql = "SELECT id_comentario, id_casa, comentario"
                       +" FROM comentarios;";
            consultarBase(sql);
            Comentario comentario = null;
            ArrayList <Comentario> listacomentarios = new ArrayList <>();
            while (resultado.next()) {                
                comentario = new Comentario();
                comentario.setId_comentario(resultado.getInt(1));
                comentario.setId_casa(resultado.getInt(2));
                comentario.setComentario(resultado.getString(3));
                listacomentarios.add(comentario);
            }
            return listacomentarios;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioDAO, listarComentarios");
        } finally {
            desconectarBase();
        }
    }
    
    public ArrayList <Comentario> listarComentariosSQL(String sql) throws Exception {
        try {
            consultarBase(sql);
            Comentario comentario = null;
            ArrayList <Comentario> listacomentarios = new ArrayList <>();
            while (resultado.next()) {                
                comentario = new Comentario();
                comentario.setId_comentario(resultado.getInt(1));
                comentario.setId_casa(resultado.getInt(2));
                comentario.setComentario(resultado.getString(3));
                listacomentarios.add(comentario);
            }
            return listacomentarios;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioDAO, listarComentariosSQL");
        } finally {
            desconectarBase();
        }
    }
    
    public ArrayList <String> listarComentario (String sql) throws Exception {  //para ej H (Solo pone el comentario en la lista).
        try {
            consultarBase(sql);
            Comentario com = null;
            ArrayList <String> listacom = new ArrayList <>();
            while (resultado.next()) {
                listacom.add(resultado.getString(15));
            }
            return listacom;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioDAO, imprimirComentario.");
        } finally {
            desconectarBase();
        }
    }
}
