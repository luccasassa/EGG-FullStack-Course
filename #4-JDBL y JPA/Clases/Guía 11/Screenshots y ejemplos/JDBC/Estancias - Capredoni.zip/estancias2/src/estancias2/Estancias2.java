package estancias2;
import estancias2.servicios.CasaServicio;
import estancias2.servicios.ClienteServicio;
import estancias2.servicios.FamiliaServicio;
import java.time.LocalDate;
import java.util.Scanner;
/*
 * @author Pablo
 */
public class Estancias2 {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        
        
        ClienteServicio cliente = new ClienteServicio();
        // cliente.imprimirClientes();
        
        //cliente.imprimirClientesSQL("select * from clientes;");
        
        
        FamiliaServicio familia = new FamiliaServicio();
//        familia.imprimirFamiliaSQL("select * from familias\n" +
//                                   "where num_hijos >=3 and edad_maxima <= 10;"); // Ej A

        CasaServicio casa = new CasaServicio();
//        casa.impirmirCasasSQL("select * from casas\n" +
//                              "where pais = 'Reino Unido' and fecha_desde <= '2020-08-01' and fecha_hasta >= '2020-08-31';"); // Ej B
        
//        familia.imprimirFamiliaSQL("select * from familias \n" +
//                                   "where nombre like '%y';"); // EJ C
        
//        familia.imprimirFamiliaSQL("select * from familias\n" +
//                                   "where email like '%hotmail%';"); //Ej D
        
//        System.out.println("Ingrese una fecha: (aaaa-mm-dd)");  // inicio ejercicio E
//        LocalDate fecha_ingreso = LocalDate.parse(sc.next());
//        System.out.println("Ingrese la cantidad de dias que se va a quedar: ");
//        LocalDate fecha_salida = fecha_ingreso.plusDays(sc.nextInt());
//        String fechaing = String.valueOf(fecha_ingreso);
//        String fechasal = String.valueOf(fecha_salida);
//        System.out.println("Fecha ingreso: "+fechaing+" Fecha salida: "+fechasal);
//        casa.impirmirCasasSQL("select * from casas\n" +
//                              "where fecha_desde <= '"+fechaing+"' and fecha_hasta >= '"+fechasal+"';");  // Fin ej E

//        casa.impirmirCasasSQL("select id_casa, calle, numero, codigo_postal, ciudad, pais, fecha_desde, fecha_hasta, tiempo_minimo, tiempo_maximo, (precio_habitacion*1.05), tipo_vivienda from casas\n" +
//                              "where pais = 'Reino Unido';");  //Ej F
        
//        casa.imprimirDatosG("select count(*), pais from casas\n" +
//                            "group by pais;"); //Ej G
        
//        casa.impirmirCasasSQL("select * from casas c\n" +  //Ppio ej I
//                              "inner join comentarios o\n" +
//                              "on o.id_casa = c.id_casa\n" +
//                              "and comentario like '%limpia%'\n" +
//                              "and pais = 'Reino Unido';"); // Fin ej I
        
        
        
        
        
        
        
        
        
        
        
        
    }

}
