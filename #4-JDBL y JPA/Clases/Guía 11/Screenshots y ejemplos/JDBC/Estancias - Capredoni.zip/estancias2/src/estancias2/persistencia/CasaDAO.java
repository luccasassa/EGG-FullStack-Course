package estancias2.persistencia;

import estancias2.entidades.Casa;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class CasaDAO extends DAO{

    public ArrayList <Casa> listarCasa() throws Exception {
        try {
            // Primero armo la query que voy a enviar a SQL
            String sql = "SELECT id_casa, calle, numero, codigo_postal, ciudad, pais, fecha_desde, fecha_hasta, tiempo_minimo, tiempo_maximo, precio_habitacion, tipo_vivienda"
                        +" FROM casas;";
            // Segundo: Consulto a la base de datos
            consultarBase(sql);
            // Tercero: Recorrer el resultado 
              // Creo un objeto nulo
            Casa casa = null;
              // Instancio una lista
            ArrayList <Casa> casas = new ArrayList<>();
              // Mientras haya resultados, voy a ir guardando las filas en la lista. Cada fila es una Casa
            while (resultado.next()){
                casa = new Casa();
                casa.setId_casa(resultado.getInt(1));
                casa.setCalle(resultado.getString(2)); 
                casa.setNumero(resultado.getInt(3)); 
                casa.setCodigo_postal(resultado.getString(4));
                casa.setCiudad(resultado.getString(5));
                casa.setPais(resultado.getString(6));
                casa.setFecha_desde(resultado.getString(7));
                casa.setFecha_hasta(resultado.getString(8));
                casa.setTiempo_minimo(resultado.getInt(9));
                casa.setTiempo_maximo(resultado.getInt(10));
                casa.setPrecio_habitacion(resultado.getDouble(11));
                casa.setTipo_vivienda(resultado.getString(12));
                casas.add(casa);
            }
            return casas;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaDAO, listarCasa");
        } finally {
            desconectarBase();
        }
    }
    
    public ArrayList <Casa> listarCasaSQL(String sql) throws Exception {
        try {
            consultarBase(sql);
            Casa casa = null;
            ArrayList <Casa> casas = new ArrayList<>();
            while (resultado.next()){
                casa = new Casa();
                casa.setId_casa(resultado.getInt(1));
                casa.setCalle(resultado.getString(2)); 
                casa.setNumero(resultado.getInt(3)); 
                casa.setCodigo_postal(resultado.getString(4));
                casa.setCiudad(resultado.getString(5));
                casa.setPais(resultado.getString(6));
                casa.setFecha_desde(resultado.getString(7));
                casa.setFecha_hasta(resultado.getString(8));
                casa.setTiempo_minimo(resultado.getInt(9));
                casa.setTiempo_maximo(resultado.getInt(10));
                casa.setPrecio_habitacion(resultado.getDouble(11));
                casa.setTipo_vivienda(resultado.getString(12));
                casas.add(casa);
            }
            return casas;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaDAO, listarCasaSQL");
        } finally {
            desconectarBase();
        }
    }
    
    public void listarG(String sql) throws Exception {
        try {
            consultarBase(sql);
            System.out.println("Cantidad de casas por paices:");
            while (resultado.next()) {  
                System.out.println("   -Pais: "+resultado.getString(2)+" > "+resultado.getInt(1)+" casa/s.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaDAO, listarG");
        }
    }
    
    
}
