package estancias2.servicios;

import estancias2.entidades.Casa;
import estancias2.entidades.Comentario;
import estancias2.persistencia.CasaDAO;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class CasaServicio {

    public CasaDAO casadao;

    public CasaServicio() {
        this.casadao = new CasaDAO();
    }
    
    public ArrayList <Casa> listarCasa() throws Exception {
        try {
            ArrayList <Casa> listacasas = casadao.listarCasa();
            return listacasas;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaServicio, listarCasa");
        }
    }
    
    public void impirmirCasas () throws Exception{
        try {
            ArrayList <Casa> listacasas = listarCasa();
            if (listacasas.isEmpty()) {
                System.out.println("La lista de casas esta vacia.");
            } else {
                System.out.println("Lista de Casas:");
                int count=1;
                for (Casa listacasa : listacasas) {
                    System.out.print(count+"> ");
                    listacasa.imprimirCasa();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaServicio, imprimirCasas");
        }
    }
    
    public ArrayList <Casa> listarCasaSQL(String sql) throws Exception {
        try {
            ArrayList <Casa> listacasas = casadao.listarCasaSQL(sql);
            return listacasas;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaServicio, listarCasaSQL");
        }
    }
    
    public void impirmirCasasSQL (String sql) throws Exception{
        try {
            ArrayList <Casa> listacasas = listarCasaSQL(sql);
            ArrayList <String> listacom = null;
            if (listacasas.isEmpty()) {
                System.out.println("La lista de casas esta vacia.");
            } else {
                System.out.println("Lista de Casas:");
                int count=1;
                Boolean existeComentario = false;
                if (sql.equals("select * from casas c\n" +
                              "inner join comentarios o\n" +
                              "on o.id_casa = c.id_casa\n" +
                              "and comentario like '%limpia%'\n" +
                              "and pais = 'Reino Unido';")) {
                        ComentarioServicio cs = new ComentarioServicio();
                        listacom = cs.listarComentariosH(sql);
                        existeComentario = true;
                    }
                for (Casa listacasa : listacasas) {
                    System.out.print(count+"> ");
                    listacasa.imprimirCasa();
                    if (existeComentario) {  // Va a agregar el comentario solo en caso de que exista (ej H).
                        System.out.println("   Comentario: "+listacom.get(count-1));
                    }
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaServicio, imprimirCasasSQL");
        }
    }
    
    public void imprimirDatosG (String sql) throws Exception {
        try {
            casadao.listarG(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en CasaServicio, imprimirDatosG");
        }
    }
}
