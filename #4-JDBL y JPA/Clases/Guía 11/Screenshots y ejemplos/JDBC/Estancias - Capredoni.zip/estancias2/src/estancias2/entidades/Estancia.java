package estancias2.entidades;

import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author Pablo
 */
public class Estancia {

    private Integer id_estancia;  // PK
    private Integer id_cliente;  // FK (cliente)id_cliente
    private Integer id_casa;  // FK (casa)id_casa
    private String nombre_huesped;
    private LocalDate fecha_desde;  // en SQL es "date"
    private LocalDate fecha_hasta;

    public Estancia(Integer id_estancia, Integer id_cliente, Integer id_casa, String nombre_huesped, LocalDate fecha_desde, LocalDate fecha_hasta) {
        this.id_estancia = id_estancia;
        this.id_cliente = id_cliente;
        this.id_casa = id_casa;
        this.nombre_huesped = nombre_huesped;
        this.fecha_desde = fecha_desde;
        this.fecha_hasta = fecha_hasta;
    }

    public Estancia() {
    }

    public Integer getId_estancia() {
        return id_estancia;
    }

    public void setId_estancia(Integer id_estancia) {
        this.id_estancia = id_estancia;
    }

    public Integer getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(Integer id_cliente) {
        this.id_cliente = id_cliente;
    }

    public Integer getId_casa() {
        return id_casa;
    }

    public void setId_casa(Integer id_casa) {
        this.id_casa = id_casa;
    }

    public String getNombre_huesped() {
        return nombre_huesped;
    }

    public void setNombre_huesped(String nombre_huesped) {
        this.nombre_huesped = nombre_huesped;
    }

    public LocalDate getFecha_desde() {
        return fecha_desde;
    }

    public void setFecha_desde(String fecha_desde) {
        LocalDate localDate = Date.valueOf(fecha_desde).toLocalDate();
        this.fecha_desde = localDate;
    }

    public LocalDate getFecha_hasta() {
        return fecha_hasta;
    }

    public void setFecha_hasta(String fecha_hasta) {
        LocalDate localDate = Date.valueOf(fecha_hasta).toLocalDate();
        this.fecha_hasta = localDate;
    }
    
    public void imprimirEstancia() {
        System.out.println("ID: "+id_estancia+
                "\n   ID Cliente asociado: "+id_cliente+
                "\n   ID Casa asociada: "+id_casa+
                "\n   Nombre Huesped: "+nombre_huesped+
                "\n   Fecha desde: "+fecha_desde+
                "\n   Fecha hasta: "+fecha_hasta);
    }
}
