package estancias2.servicios;

import estancias2.entidades.Cliente;
import estancias2.persistencia.ClienteDAO;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class ClienteServicio {

    // Llamado al ClienteDAO --> es un atributo del servicio que se inicializa en el constructor.
    public ClienteDAO clientedao;

    public ClienteServicio() {
        this.clientedao = new ClienteDAO();
    }
    
    public ArrayList<Cliente> listarCliente() throws Exception {
        try {
            ArrayList<Cliente> clientes = clientedao.listarCliente();
            return clientes;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteServicio, listarCliente");
        }
    }
    
    public void imprimirClientes() throws Exception {
        try {
            ArrayList <Cliente> listaClientes = listarCliente();
            if (listaClientes.isEmpty()) {
                System.out.println("La lista de Clientes esta vacia.");
            } else {
                System.out.println("Lista de Clientes:");
                int count = 1;
                for (Cliente c : listaClientes) {
                    System.out.print(count+"> ");
                    c.imprimirCliente();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteServicio, imprimirClientes");
        }
    }
    
    public ArrayList<Cliente> listarClienteSQL(String sql) throws Exception {
        try {
            ArrayList<Cliente> clientes = clientedao.listarClienteSQL(sql);
            return clientes;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteServicio, listarClienteSQL");
        }
    }
    
    public void imprimirClientesSQL(String sql) throws Exception {
        try {
            ArrayList <Cliente> listaClientes = listarClienteSQL(sql);
            if (listaClientes.isEmpty()) {
                System.out.println("La lista de CLientes esta vacia.");
            } else {
                System.out.println("Lista de Clientes:");
                int count = 1;
                for (Cliente c : listaClientes) {
                    System.out.print(count+"> ");
                    c.imprimirCliente();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteServicio, imprimirClientesSQL");
        }
    }
    
    public void updateClienteSQL(String sql) throws Exception {
        try {
            clientedao.updateClienteSQL(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteServicio, updateClienteSQL");
        }
    }
}
