package estancias2.servicios;

import estancias2.entidades.Familia;
import estancias2.persistencia.FamiliaDAO;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class FamiliaServicio {
    
    public FamiliaDAO familiadao;

    public FamiliaServicio() {
        this.familiadao = new FamiliaDAO();
    }
    
    public ArrayList <Familia> listarFamilia() throws Exception {
        try {
            ArrayList <Familia> listaFamilia = familiadao.listarFamilia();
            return listaFamilia;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en FamiliaServicio, listarFamilia.");
        }
    }
    
    public void imprimirFamilia() throws Exception {
        try {
            ArrayList <Familia> listaFamilia = listarFamilia();
            if (listaFamilia.isEmpty()) {
                System.out.println("La lista de Familia esta vacia.");
            } else {
                System.out.println("Lista de Familias:");
                int count =1;
                for (Familia familia : listaFamilia) {
                    System.out.print(count+"> ");
                    familia.imprimirFamilia();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en FamiliaServicio, imprimirFamilia");
        }
    }
    
        public ArrayList <Familia> listarFamiliaSQL(String sql) throws Exception {
        try {
            ArrayList <Familia> listaFamilia = familiadao.listarFamiliaSQL(sql);
            return listaFamilia;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en FamiliaServicio, listarFamiliaSQL.");
        }
    }
    
    public void imprimirFamiliaSQL(String sql) throws Exception {
        try {
            ArrayList <Familia> listaFamilia = listarFamiliaSQL(sql);
            if (listaFamilia.isEmpty()) {
                System.out.println("La lista de Familia esta vacia.");
            } else {
                System.out.println("Lista de Familias:");
                int count =1;
                for (Familia familia : listaFamilia) {
                    System.out.print(count+"> ");
                    familia.imprimirFamilia();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en FamiliaServicio, imprimirFamiliaSQL");
        }
    }

}
