package estancias2.persistencia;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;

/**
 *
 * @author Pablo DATA ACCESS OBJECT
 */
public class DAO {

    //OBJETO CONNECTION ---> encargado de INICIAR-TENER-MANTENER la conexion
    protected Connection conexion = null;

    //OBJETO RESULSET ---> guarda todos los datos que llegan de la DB (las filas de la query)
    protected ResultSet resultado = null;

    //OBJETO STATEMENT ---> "TIENE" las consultas.. es donde generamos las sentencias a ejecutar
    protected Statement sentencia = null;

    private final String user = "root";
    private final String password = "rootegg";
    private final String database = "estancias_exterior";  //SIEMPRE debo colocar el nombre de la base de datos a la que me quiero conectar.

    protected void conectarBase() throws Exception {
        try {
            //registrar el Driver de MySQL
            Class.forName("com.mysql.jdbc.Driver");
            //URL de la DB
            String urlDataBase = "jdbc:mysql://localhost:3306/" + database + "?useSSL=false";

            //establecemos la conexion!
            conexion = (Connection) DriverManager.getConnection(urlDataBase, user, password);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en DAO, conectarBase");
        }
    }

    protected void consultarBase(String sql) throws Exception {
        try {
            //conectamos a la base
            conectarBase();

            //creamos la sentencia!
            sentencia = (Statement) conexion.createStatement();

            //ejecutamos la sentencia, y guardamos en el resultset:
            resultado = sentencia.executeQuery(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en DAO, consultarBase");
        }
    }

    protected void desconectarBase() throws Exception {
        try {
            if (resultado != null) {
                resultado.close();
            }
            if (sentencia != null) {
                sentencia.close();
            }
            if (conexion != null) {
                conexion.close();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en DAO, desconectarBase");
        }
    }
    
    protected void updateBase(String sql) throws Exception {
        try {
            //conectamos a la base
            conectarBase();

            //creamos la sentencia!
            sentencia = (Statement) conexion.createStatement();

            //ejecutamos la sentencia
            sentencia.executeUpdate(sql);
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en DAO, updateBase");
        }
    }
}
