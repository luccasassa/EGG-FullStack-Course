package estancias2.servicios;

import estancias2.entidades.Comentario;
import estancias2.persistencia.ComentarioDAO;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class ComentarioServicio {

    public ComentarioDAO comentariodao;

    public ComentarioServicio() {
        this.comentariodao = new ComentarioDAO();
    }
    
    public ArrayList <Comentario> listarComentario() throws Exception {
        try {
            ArrayList <Comentario> listacomentarios = comentariodao.listarComentarios();
            return listacomentarios;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioServicio, listarComentario");
        }
    }
    
    public void imprimirComentario() throws Exception {
        try {
            ArrayList <Comentario> listacomentario = listarComentario();
            if (listacomentario.isEmpty()) {
                System.out.println("La lista de comentarios esta vacia.");
            } else {
                System.out.println("Lista de Comentarios:");
                int count =1;
                for (Comentario comentario : listacomentario) {
                    System.out.print(count+"> ");
                    comentario.imprimirComentario();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioServicio, imprimirComentario");
            
        }
    }
    
    public ArrayList <Comentario> listarComentarioSQL(String sql) throws Exception {
        try {
            ArrayList <Comentario> listacomentarios = comentariodao.listarComentariosSQL(sql);
            return listacomentarios;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioServicio, listarComentarioSQL");
        }
    }
    
    public void imprimirComentarioSQL(String sql) throws Exception {
        try {
            ArrayList <Comentario> listacomentario = listarComentarioSQL(sql);
            if (listacomentario.isEmpty()) {
                System.out.println("La lista de comentarios esta vacia.");
            } else {
                System.out.println("Lista de Comentarios:");
                int count =1;
                for (Comentario comentario : listacomentario) {
                    System.out.print(count+"> ");
                    comentario.imprimirComentario();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioServicio, imprimirComentarioSQL");
            
        }
    }
    
    public ArrayList <String> listarComentariosH(String sql) throws Exception {
        try {
            ArrayList <String> listacom = comentariodao.listarComentario(sql);
            return listacom;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ComentarioService, listarComentariosH");
        }
    }
}
