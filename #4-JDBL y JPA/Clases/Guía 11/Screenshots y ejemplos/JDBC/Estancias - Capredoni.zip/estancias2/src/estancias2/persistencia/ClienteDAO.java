package estancias2.persistencia;

import estancias2.entidades.Cliente;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class ClienteDAO extends DAO {

    public ArrayList<Cliente> listarCliente() throws Exception {
        try {
            //Armo la query que voy a enviar a MySQL
            String sql = "SELECT id_cliente, nombre, calle, numero, codigo_postal, ciudad, pais, email"
                       + " FROM clientes";
            //Consulto la base de datos
            consultarBase(sql);

            //Recorrer el resultado
            Cliente cliente = null;
            ArrayList<Cliente> clientes = new ArrayList<>();
            while (resultado.next()) {
                cliente = new Cliente();
                cliente.setId_cliente(resultado.getInt(1));  //id_cliente
                cliente.setNombre(resultado.getString(2));  //nombre
                cliente.setCalle(resultado.getString(3));  //calle
                cliente.setNumero(resultado.getInt(4)); //numero
                cliente.setCodigo_postal(resultado.getString(5));  //codigo_postal
                cliente.setCiudad(resultado.getString(6)); //ciudad
                cliente.setPais(resultado.getString(7));  //pais
                cliente.setEmail(resultado.getString(8));  //email
                clientes.add(cliente);
            }
            return clientes;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteDAO, listarCliente");
        } finally {
            desconectarBase();
        }
    }
    
    public ArrayList<Cliente> listarClienteSQL(String sql) throws Exception {
        try {
            consultarBase(sql);
            Cliente cliente = null;
            ArrayList<Cliente> clientes = new ArrayList<>();
            while (resultado.next()) {
                cliente = new Cliente();
                cliente.setId_cliente(resultado.getInt(1));  //id_cliente
                cliente.setNombre(resultado.getString(2));  //nombre
                cliente.setCalle(resultado.getString(3));  //calle
                cliente.setNumero(resultado.getInt(4)); //numero
                cliente.setCodigo_postal(resultado.getString(5));  //codigo_postal
                cliente.setCiudad(resultado.getString(6)); //ciudad
                cliente.setPais(resultado.getString(7));  //pais
                cliente.setEmail(resultado.getString(8));  //email
                clientes.add(cliente);
            }
            return clientes;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteDAO, listarClienteSQL");
        } finally {
            desconectarBase();
        }
    }
    
    public void updateClienteSQL (String sql) throws Exception {
        try {
            updateBase(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en ClienteDAO, updateCLienteSQL.");
        } finally {
            desconectarBase();
        }
    }
}
