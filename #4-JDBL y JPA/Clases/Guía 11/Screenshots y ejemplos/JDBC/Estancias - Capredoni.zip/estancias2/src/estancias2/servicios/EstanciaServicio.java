package estancias2.servicios;

import estancias2.entidades.Estancia;
import estancias2.persistencia.EstanciaDAO;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class EstanciaServicio {

    public EstanciaDAO estanciadao;

    public EstanciaServicio() {
        this.estanciadao = new EstanciaDAO();
    }
    
    public ArrayList <Estancia> listarEstancia() throws Exception {
        try {
            ArrayList <Estancia> listaEstancias = estanciadao.listarEstancia();
            return listaEstancias;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciaServicio, listarEstancia");
        }
    }
    
    public void imprimirEstancia() throws Exception {
        try {
            ArrayList <Estancia> listaEstancia = listarEstancia();
            if (listaEstancia.isEmpty()) {
                System.out.println("La lista de estancias esta vacia.");
            } else {
                System.out.println("Lista de Estancias:");
                int count =1;
                for (Estancia estancia : listaEstancia) {
                    System.out.print(count+"> ");
                    estancia.imprimirEstancia();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciasServicio, imprimirEstancia");
        }
    }
    
    public ArrayList <Estancia> listarEstanciaSQL(String sql) throws Exception {
        try {
            ArrayList <Estancia> listaEstancias = estanciadao.listarEstanciaSQL(sql);
            return listaEstancias;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciaServicio, listarEstanciaSQL");
        }
    }
    
    public void imprimirEstanciaSQL(String sql) throws Exception {
        try {
            ArrayList <Estancia> listaEstancia = listarEstanciaSQL(sql);
            if (listaEstancia.isEmpty()) {
                System.out.println("La lista de estancias esta vacia.");
            } else {
                System.out.println("Lista de Estancias:");
                int count =1;
                for (Estancia estancia : listaEstancia) {
                    System.out.print(count+"> ");
                    estancia.imprimirEstancia();
                    count ++;
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciasServicio, imprimirEstanciaSQL");
        }
    }
    
    public void updateEstanciaSQL (String sql) throws Exception {
        try {
            estanciadao.updateEstanciaSQL(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        throw new Exception("Error en EstanciaServicio, updateEstanciaSQL");
        }
    }
}
