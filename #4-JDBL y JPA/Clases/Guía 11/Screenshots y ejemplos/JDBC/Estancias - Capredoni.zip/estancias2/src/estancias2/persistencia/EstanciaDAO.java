package estancias2.persistencia;

import estancias2.entidades.Estancia;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class EstanciaDAO extends DAO{
    
    public ArrayList <Estancia> listarEstancia() throws Exception {
        try {
            String sql = "SELECT id_estancia, id_cliente, id_casa, nombre_huesped, fecha_desde, fecha_hasta"
                        +" FROM estancias;";
            consultarBase(sql);
            Estancia estancia = null;
            ArrayList <Estancia> listaEstancia = new ArrayList<>();
            while (resultado.next()) {                
                estancia = new Estancia();
                estancia.setId_estancia(resultado.getInt(1));
                estancia.setId_cliente(resultado.getInt(2));
                estancia.setId_casa(resultado.getInt(3));
                estancia.setNombre_huesped(resultado.getString(4));
                estancia.setFecha_desde(resultado.getString(5));
                estancia.setFecha_hasta(resultado.getString(6));
                listaEstancia.add(estancia);
            }
            return listaEstancia;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciaDAO, listarEstancia");
        } finally {
            desconectarBase();
        }
    }
    
    public ArrayList <Estancia> listarEstanciaSQL(String sql) throws Exception {
        try {
            consultarBase(sql);
            Estancia estancia = null;
            ArrayList <Estancia> listaEstancia = new ArrayList<>();
            while (resultado.next()) {                
                estancia = new Estancia();
                estancia.setId_estancia(resultado.getInt(1));
                estancia.setId_cliente(resultado.getInt(2));
                estancia.setId_casa(resultado.getInt(3));
                estancia.setNombre_huesped(resultado.getString(4));
                estancia.setFecha_desde(resultado.getString(5));
                estancia.setFecha_hasta(resultado.getString(6));
                listaEstancia.add(estancia);
            }
            return listaEstancia;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciaDAO, listarEstanciaSQL");
        } finally {
            desconectarBase();
        }
    }
    
    public void updateEstanciaSQL (String sql) throws Exception {
        try {
            updateBase(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en EstanciaDAO, updateEstanciaSQL");
        } finally {
            desconectarBase();
        }
    }

}
