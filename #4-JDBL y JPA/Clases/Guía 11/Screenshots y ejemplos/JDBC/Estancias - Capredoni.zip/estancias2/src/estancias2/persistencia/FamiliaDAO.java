package estancias2.persistencia;

import estancias2.entidades.Familia;
import java.util.ArrayList;

/**
 *
 * @author Pablo
 */
public class FamiliaDAO extends DAO{

    public ArrayList <Familia> listarFamilia() throws Exception {
        try {
            String sql = "SELECT id_familia, nombre, edad_minima, edad_maxima, num_hijos, email, id_casa_familia"
                        +" FROM familias;";
            consultarBase(sql);
            Familia familia = null;
            ArrayList <Familia> listaFamilia = new ArrayList<>();
            while (resultado.next()) {                
                familia = new Familia();
                familia.setId_familia(resultado.getInt(1));
                familia.setNombre(resultado.getString(2));
                familia.setEdad_minima(resultado.getInt(3));
                familia.setEdad_maxima(resultado.getInt(4));
                familia.setNum_hijos(resultado.getInt(5));
                familia.setEmail(resultado.getString(6));
                familia.setId_casa_familia(resultado.getInt(7));
                listaFamilia.add(familia);
            }
            return listaFamilia;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en FamiliaDAO, listarFamilia");
        } finally {
            desconectarBase();
        }
    }
    
    public ArrayList <Familia> listarFamiliaSQL(String sql) throws Exception {
        try {
            consultarBase(sql);
            Familia familia = null;
            ArrayList <Familia> listaFamilia = new ArrayList<>();
            while (resultado.next()) {                
                familia = new Familia();
                familia.setId_familia(resultado.getInt(1));
                familia.setNombre(resultado.getString(2));
                familia.setEdad_minima(resultado.getInt(3));
                familia.setEdad_maxima(resultado.getInt(4));
                familia.setNum_hijos(resultado.getInt(5));
                familia.setEmail(resultado.getString(6));
                familia.setId_casa_familia(resultado.getInt(7));
                listaFamilia.add(familia);
            }
            return listaFamilia;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new Exception("Error en FamiliaDAO, listarFamiliaSQL");
        } finally {
            desconectarBase();
        }
    }
}
