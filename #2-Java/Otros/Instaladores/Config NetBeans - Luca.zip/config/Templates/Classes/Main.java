/*
*
*/

<#if package?? && package != "">
package ${package};
</#if>

public class ${name} {
    
    public static void main(String[] args) {
        
    }
}
